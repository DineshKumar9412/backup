import random
import os
from tensorflow import keras
from tensorflow.keras import models
from tensorflow.keras import layers
from tensorflow.keras import optimizers
from tensorflow.keras.preprocessing import image
from tensorflow.keras.applications import EfficientNetB0
import numpy as np
from tensorflow.keras.preprocessing.image import ImageDataGenerator

width = 150
height = 150
input_shape = (height, width, 3)
dropout_rate = 0.2

conv_base = EfficientNetB0(weights='imagenet', include_top=False, input_shape=input_shape)


model = models.Sequential()
model.add(conv_base)
model.add(layers.GlobalMaxPooling2D(name="gap"))
# model.add(layers.Flatten(name="flatten"))
if dropout_rate > 0:
    model.add(layers.Dropout(dropout_rate, name="dropout_out"))
# model.add(layers.Dense(256, activation='relu', name="fc1"))
model.add(layers.Dense(3, activation='softmax', name="fc_out"))


img_path = "test/rock/rock-hires1_png.rf.7b38054057b744fc4a210351a5cfbc21.jpg"
img = image.load_img(img_path, target_size=(height, width))
# Convert it to a Numpy array with target shape.
x = image.img_to_array(img)
# Reshape
x = x.reshape((1,) + x.shape)
x /= 255.
result = model.predict([x])[0][0]
# print(result)
result_verbose = model.predict([x])
s = np.argmax(result_verbose)
print(s)
if result > 0.5:
    animal = "cat"
    print(result_verbose)
else:
    animal = "dog"
    result = 1 - result
    print(result_verbose)
