from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing import image_dataset_from_directory
import numpy as np
from numpy import expand_dims
from matplotlib import pyplot as plt
import cv2
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing import image

model = load_model('my_traffic_model_105_B7.hdf5')

img = image.load_img('hhhhhhhhh.jpg', target_size=(244, 244))
# print(img.shape)
x = image.img_to_array(img)
x = np.expand_dims(x, axis=0)
pred = model.predict(x)
# print(pred)
res = np.amax(pred)
print(res)
fin = np.argmax(pred[0])
print(fin)
