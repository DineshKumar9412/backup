import tensorflow
from PIL import Image
from tensorflow.keras.applications.vgg16 import preprocess_input
import base64
from io import BytesIO
import json
import random
import cv2
from tensorflow.keras.models import load_model
import numpy as np
from tensorflow.keras.preprocessing import image

model = load_model('vgg16_face.h5')

# # Loading the cascades
# face_cascade = cv2.CascadeClassifier('face_count.xml')
#
# #
# # def face_extractor(img):
# #     # Function detects faces and returns the cropped face
# #     # If no face detected, it returns the input image
# #
# #     # gray = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
# #     faces = face_cascade.detectMultiScale(img, 1.3, 5)
#
#     # if faces is ():
#     #     return None
#     #
#     # # Crop all faces found
#     # for (x, y, w, h) in faces:
#     #     cv2.rectangle(img, (x, y), (x + w, y + h), (0, 255, 255), 2)
#     #     cropped_face = img[y:y + h, x:x + w]
#     #
#     #     return cropped_face
face = cv2.imread('face/test/Hari Kumar.R/2.jpg')
# print(face)

# face = face_extractor(face)
# face = face
# print(face)
if type(face) is np.ndarray:
    # print("yes")
    # ResultMap = {0: 'Ashok', 1: 'Hari', 2: 'Thiru'}
    face = cv2.resize(face, (224, 224))


    im = Image.fromarray(face, 'RGB')
    # Resizing into 128x128 because we trained the model with this image size.
    img_array = np.array(im)
    # Our keras model used a 4D tensor, (images x height x width x channel)
    # So changing dimension 128x128x3 into 1x128x128x3
    img_array = np.expand_dims(img_array, axis=0)
    # print(img_array)
    pred = model.predict(img_array)
    print(pred)
    # print("gfgfg", ResultMap[np.argmax(pred)])