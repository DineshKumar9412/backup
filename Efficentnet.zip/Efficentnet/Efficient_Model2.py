# https://www.youtube.com/watch?v=_xbStNTDZ1o&t=1584s
from tensorflow.keras.preprocessing import image_dataset_from_directory
from tensorflow.keras.layers.experimental import preprocessing
from tensorflow.keras import Sequential
from tensorflow import expand_dims
from tensorflow.keras.applications import EfficientNetB0
from tensorflow.keras.layers import GlobalAvgPool2D, GlobalAveragePooling2D
from tensorflow.keras import Input
from tensorflow.keras.layers import Dense, Dropout
from tensorflow.keras import Model
from tensorflow.keras.callbacks import ModelCheckpoint, EarlyStopping
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.losses import SparseCategoricalCrossentropy
import os
import numpy as np
base_dir = 'traffics/'

batch_size = 32
img_size = (244, 244)
img_shape = (244, 244, 3)

train_ds = image_dataset_from_directory(base_dir + 'train/',
                                        shuffle=True,
                                        batch_size=batch_size,
                                        image_size=img_size)

test_ds = image_dataset_from_directory(base_dir + 'test/',
                                        shuffle=True,
                                        batch_size=batch_size,
                                        image_size=img_size)

val_ds = image_dataset_from_directory(base_dir + 'valid/',
                                        shuffle=True,
                                        batch_size=batch_size,
                                        image_size=img_size)

data_augmentation = Sequential([
                                preprocessing.RandomFlip('horizontal'),
                                preprocessing.RandomRotation(0.2)
])


base_model = EfficientNetB0(include_top=False,
                            weights='imagenet',
                            input_shape=img_shape)
# base_model.summary()

image_batch, label_batch = next(iter(train_ds))
feature_batch = base_model(image_batch)
# print(feature_batch.shape)
#
print(GlobalAveragePooling2D()(feature_batch).shape)


inputs = Input(shape=img_shape)
x = data_augmentation(inputs)
x = base_model(x, training=False)
x = GlobalAveragePooling2D()(x)
x = Dropout(0.2)(x)
outputs = Dense(10, activation='softmax')(x)
model = Model(inputs, outputs)

file_path = 'my_traffic_model_105_B7.hdf5'

earlystop = EarlyStopping(
    monitor='val_accuracy',
    min_delta=0.001,
    patience=10,
    verbose=2,
    mode='auto'
)
checkpoint = ModelCheckpoint(
    file_path,
    monitor='val_accuracy',
    verbose=2,
    save_best_only=True,
    mode='max',
    save_weights_only=False
)
callbacks = [checkpoint, earlystop]


model.compile(loss=SparseCategoricalCrossentropy(from_logits=False),
              optimizer=Adam(learning_rate=0.0001),
              metrics=['accuracy'])


model.fit(train_ds, epochs=3,
          validation_data=val_ds, verbose=1, callbacks=callbacks)



