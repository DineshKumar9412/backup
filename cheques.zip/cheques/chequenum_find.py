import numpy as np
import pytesseract
import cv2

img = cv2.imread("images/vj_cheque.jpeg", cv2.IMREAD_UNCHANGED)
width = 1000
height = 500
diaments = (width, height)
resize = cv2.resize(img, diaments, interpolation=cv2.INTER_AREA)
crop = resize[390:490, 0:1000]
# crop = resize[390:490, 900:1000]
check_image = cv2.cvtColor(crop, cv2.COLOR_RGB2BGR)
text = pytesseract.image_to_string(check_image, lang='mcr')
cv2.imwrite("op.png",crop)
print(text)