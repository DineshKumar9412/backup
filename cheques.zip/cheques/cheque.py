import numpy
import pytesseract
import cv2
from flask import Flask
from flask_restplus import Api, Resource, reqparse
from werkzeug.datastructures import FileStorage
from flask import jsonify
app = Flask(__name__)
api = Api(app)


upload_parser = api.parser()
upload_parser.add_argument('Upload File',
                           location='files',
                           type=FileStorage)


@api.route('/Cheque Number/')
@api.expect(upload_parser)
class UploadDemo(Resource):
    def post(self):
         try:
            args = upload_parser.parse_args()
            npimg = numpy.fromfile(args.get('Upload File'), numpy.uint8)
            image = cv2.imdecode(npimg, cv2.IMREAD_GRAYSCALE)
            width = 1000
            height = 500
            diaments = (width, height)
            resize = cv2.resize(image, diaments, interpolation=cv2.INTER_AREA)
            crop = resize[390:490, 0:1000]
            # crop = resize[390:490, 900:1000]
            check_image = cv2.cvtColor(crop, cv2.COLOR_RGB2BGR)
            text = pytesseract.image_to_string(check_image, lang='mcr')

            return jsonify({"Result ": text})

         except Exception as e:
             print("Exception Occured", e)
             return jsonify({"Result": e})


if __name__ == '__main__':
    app.run()