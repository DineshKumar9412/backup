import pytesseract
import cv2
from flask_restplus import Api,Resource
from flask import Flask,jsonify
from werkzeug.datastructures import FileStorage
import numpy

app = Flask(__name__)
api = Api()
api.init_app(app)

upload_parser = api.parser()
upload_parser.add_argument('file',
                           location='files',
                           type=FileStorage)
@api.route('/upload/')
@api.expect(upload_parser)
class UploadDemo(Resource):
    def post(self):
        args = upload_parser.parse_args()

        npimg = numpy.fromfile(args.get('file'), numpy.uint8)
        image = cv2.imdecode(npimg, cv2.IMREAD_GRAYSCALE)
        text = pytesseract.image_to_string(image, lang='eng')
        return jsonify({"result": text})

@api.route('/cheque/')
@api.expect(upload_parser)
class UploadDemo(Resource):
    def post(self):
        args = upload_parser.parse_args()

        npimg = numpy.fromfile(args.get('file'), numpy.uint8)
        image = cv2.imdecode(npimg, cv2.IMREAD_GRAYSCALE)
        width = 1000
        height = 500
        diaments = (width, height)
        resize = cv2.resize(image, diaments, interpolation=cv2.INTER_AREA)
        crop = resize[390:490, 0:1000]
        check_image = cv2.cvtColor(crop, cv2.COLOR_RGB2BGR)

        text = pytesseract.image_to_string(check_image, lang='mcr')
        print(text)
        return jsonify({"result": text})

if __name__ == '__main__':
    app.run(debug=True, port=8090, host="localhost")

