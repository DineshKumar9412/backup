import numpy as np
import cv2
from paddleocr import PaddleOCR

plate_cascade = cv2.CascadeClassifier('indian_license_plate.xml')
# frame = cv2.imread('car.jpg')

img = cv2.imread("cars6.jpg", cv2.IMREAD_UNCHANGED)
gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
width = 750
height = 500
diaments = (width, height)
resize = cv2.resize(img, diaments, interpolation=cv2.INTER_AREA)
print(img.shape)
print(resize.shape)

plate_rect = plate_cascade.detectMultiScale(resize, scaleFactor=1.3, minNeighbors=7)

for (x, y, w, h) in plate_rect:
    cv2.rectangle(img, (x, y), (x+w, y+h), (255, 0, 0), 2)

cv2.imshow('img',img)
cv2.waitKey(0)
cv2.destroyAllWindows()
# ocr = PaddleOCR(use_angle_cls=True, lang='en')
# result = ocr.ocr(plate_rect, cls=False)

# print(result)

#
# import cv2
#
# # Load the cascade
# face_cascade = cv2.CascadeClassifier('face.xml')
# # Read the input image
# img = cv2.imread('photos.jpeg')
# # Convert into grayscale
# gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
# # Detect faces
# faces = face_cascade.detectMultiScale(gray, 1.1, 4)
# # Draw rectangle around the faces
# for (x, y, w, h) in faces:
#     cv2.rectangle(img, (x, y), (x+w, y+h), (255, 0, 0), 2)
# # Display the output
# cv2.imshow('img', img)
# cv2.waitKey()