import cv2
import matplotlib.pyplot as plt
import numpy as np
import imutils
from paddleocr import PaddleOCR
import pandas as pd
from flask import Flask
from flask_restplus import Api, Resource, reqparse
from werkzeug.datastructures import FileStorage
import json
from flask import jsonify
app = Flask(__name__)
api = Api(app)

upload_parser = api.parser()
upload_parser.add_argument('Car Number Plate Image',
                           location='files',
                           type=FileStorage)
@api.route('/Numberplate/')
@api.expect(upload_parser)
class UploadDemo(Resource):
    def post(self):
        try:
            args = upload_parser.parse_args()
            npimg =np.fromfile(args.get('Car Number Plate Image'), np.uint8)
            image = cv2.imdecode(npimg, cv2.IMREAD_GRAYSCALE)
            img = cv2.resize(image, (600, 400))
            contours = cv2.findContours(img.copy(), cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
            contours = imutils.grab_contours(contours)
            contours = sorted(contours, key=cv2.contourArea, reverse=True)[:10]
            screenCnt = None

            for c in contours:
                peri = cv2.arcLength(c, True)
                apporx = cv2.approxPolyDP(c, 0.018 * peri, True)

                if len(apporx) == 4:
                    screenCnt = apporx
                    break

            if screenCnt is None:
                detected = 0
                print("no")
            else:
                detected = 1
            if detected == 1:
                cv2.drawContours(img, [screenCnt], -1, (0, 0, 255), 3)

            mask = np.zeros(img.shape, np.uint8)
            new_image = cv2.drawContours(mask, [screenCnt], 0, 255, -1)
            new_images = cv2.bitwise_and(img, img, mask=mask)

            (x, y) = np.where(mask == 255)
            (topx, topy) = (np.min(x), np.min(y))
            (bottomx, bottomy) = (np.max(x), np.max(y))
            cropped = img[topx: bottomx + 1, topy:bottomy + 1]

            ocr = PaddleOCR(use_angle_cls=True, lang='en')
            result = ocr.ocr(cropped, cls=False)

            dd = pd.DataFrame(result, columns=["arrays", "accuracy"])
            results = dd['accuracy']
            
            sd = []
            for x in results:
                y = x[0]
                sd.append(y)

            return jsonify({"Result": str(sd[0])})

        except Exception as e:
            print("Exception Occured", e)
            return jsonify({"Result": e})
#
if __name__ == '__main__':
    app.run(host='0.0.0.0', debug=True, port=8091)