import pandas as pd

# sf = pd.read_csv("Attendences.csv")
#
# dd = pd.DataFrame(sf, columns=["Name", "Time"])
# results = dd['Name']
# print(results)

# a = pd.read_csv('Attendences.csv')
#
# sf = a[" Time"]
# print(sf)


# af = a.drop_duplicates()
#
# print(af)

pd.read_csv("Attendences.csv").drop_duplicates(subset='Name', keep="last").to_csv('Output.csv')
