# # import face_recognition
# # image = face_recognition.load_image_file("images/musk.jpg")
# # face_locations = face_recognition.face_locations(image)
# # print(face_locations)
# #
# # import face_recognition
# # image = face_recognition.load_image_file("images/musk.jpg")
# # face_landmarks_list = face_recognition.face_landmarks(image)
# # print(face_landmarks_list)
#
# import cv2
# import face_recognition
# # define a video capture object
# vid = cv2.VideoCapture(0)
# while (True):
#     # Capture the video frame
#     # by frame
#     ret, frame = vid.read()
#     cv2.imread()
#
#     known_image = face_recognition.load_image_file(frame)
#     unknown_image = face_recognition.load_image_file("images/vijay2.jpg")
#
#     biden_encoding = face_recognition.face_encodings(known_image)[0]
#     unknown_encoding = face_recognition.face_encodings(unknown_image)[0]
#
#     results = face_recognition.compare_faces([biden_encoding], unknown_encoding)
#
#     print(results)
#
#
#
#
#     # Display the resulting frame
#     # cv2.imshow('frame', frame)
#     if cv2.waitKey(1) & 0xFF == ord('q'):
#         break
# # After the loop release the cap object
# vid.release()
# # Destroy all the windows
# cv2.destroyAllWindows()
#
#
#
# # import face_recognition
# # known_image = face_recognition.load_image_file("images/musk.jpg")
# # unknown_image = face_recognition.load_image_file("images/vijay2.jpg")
# #
# #
# # biden_encoding = face_recognition.face_encodings(known_image)[0]
# # unknown_encoding = face_recognition.face_encodings(unknown_image)[0]
# #
# #
# # results = face_recognition.compare_faces([biden_encoding], unknown_encoding)
# #
# # print(results)


import cv2
import face_recognition

cam = cv2.VideoCapture(0)

cv2.namedWindow("test")

img_counter = 0

while True:
    ret, frame = cam.read()
    if not ret:
        print("failed to grab frame")
        break
    cv2.imshow("test", frame)

    k = cv2.waitKey(1)
    if k%256 == 27:
        # ESC pressed
        print("Escape hit, closing...")
        break
    # elif k%256 == 32:
    else:
        # SPACE pressed
        img_name = "opencv_frame_{}.jpg".format(img_counter)
        # print(img_name)
        s = cv2.imwrite(img_name, frame)
        # print("{} written!".format(img_name))
        img_counter += 1

        known_image = face_recognition.load_image_file(img_name)
        unknown_image = face_recognition.load_image_file("")

        biden_encoding = face_recognition.face_encodings(known_image)[0]
        unknown_encoding = face_recognition.face_encodings(unknown_image)[0]

        results = face_recognition.compare_faces([biden_encoding], unknown_encoding)

        print(results)

cam.release()

cv2.destroyAllWindows()

